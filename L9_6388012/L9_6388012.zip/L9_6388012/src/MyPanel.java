import javax.swing.*;
import java.awt.*;

public class MyPanel extends JPanel {
//    MyPanel(){
//        this.setPreferredSize(new Dimension(500,500));
//    }

    public void paintComponent(Graphics g){
        super.paintComponent(g);
        this.setBackground(Color.darkGray);

        Graphics2D graphics = (Graphics2D) g;

        int count = 0;
        for(int i = 0 ; i <= 220 ; i+=1){
            count++;
            if(i <= 40){
                graphics.setColor(Color.LIGHT_GRAY);
            }
            else if(count % 2 == 0 && count % 3 == 0 && (i > 150)) {
                graphics.setColor(Color.white);
            }else if(count % 2 == 1 &&  count % 3 == 1 && (i<100 && i > 50) ){
                graphics.setColor(Color.PINK);
            }else if(count % 2 == 1 && count % 3 == 0 && (i > 50)){
                graphics.setColor(Color.ORANGE);
            }else if(i>150){
                graphics.setColor(Color.RED);
            }

            graphics.drawOval(i,i,30+i,30+i);
        }

    }
}
