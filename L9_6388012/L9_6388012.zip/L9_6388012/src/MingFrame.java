import javax.swing.*;

public class MingFrame extends JFrame {
    MyPanel panel = new MyPanel();

    MingFrame(){
        this.setSize(500,500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.add(panel);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }


}
