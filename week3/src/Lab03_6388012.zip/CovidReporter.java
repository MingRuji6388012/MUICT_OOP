public class CovidReporter {
    public static void main(String[] args){
        CovidProfile profile1 = new CovidProfile();
        profile1.printCovidInfo();
        profile1.printRecentCase();
        System.out.println("Death case more than 10000 ? : "+profile1.isSevere());
        System.out.println();


        CovidProfile profile2 = new CovidProfile("2021-02-03","RUSSIA", 3842145, 3304311, 72982);
        profile2.printCovidInfo();
        profile2.printRecentCase();
        System.out.println("Death case ore than 10000 ? :"+ profile2.isSevere());
        System.out.println();


        System.out.println("Profile created "+ CovidProfile.getFrequency()+ " time(s)");

    }
}
