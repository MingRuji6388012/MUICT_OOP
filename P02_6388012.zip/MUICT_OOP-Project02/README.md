## Welcome to OOP Project02 groupwork ##


* ***Discription***

    * This project is to create a program to handle "grocery store"
    * A customer can place an order either ***in-store*** or ***online***
    * For *Online order*, there is a shipping fee based on the distance
    * Customer can pay shipping fee using either ***cash***, ***credits card***, and ***e-wallet***
    * These **stocks item, customers' information, and orders** can be stored and retrieved from the log files.
    * Set of ***CLASSES*** and ***TEST_CASES*** can be modified.


**Requirement**
   * Use RegEx, Set/Map, and also exception 
   * Read & Write simple text files 
   * Basic algorithm (Sorting) 



**Due dates**

  Assigned date | Due date
  ------------|----------
  Fri 02 Apr  | Fri 30 Apr


### ***Link of Project02 details*** ### 
* [MUICT OOP Project02](https://mycourses.ict.mahidol.ac.th/login/index.php)


## 👍Fighting!👍 ##
