## TASK 1 : ***Implement item, Customer, E-Wallet, CreditCard, and Payment Classes*** ##

### Item ###
* The `Item` class represent items in store
* Each item must have ***name, price*** and ***quantity*** in stock
* Some items need to include ***sell tax*** --> Need indicator to identify the taxable item


### Customer ###
* Each customer must have ***name*** and ***ID***
* The ***ID*** can be either *auto generated (using ID static field)* or *identify in constructor*
* For ***Online customer***, he/she has to provide ***Shipping Distance***
* `CustomerOnline` class **extends** the `Customer` class

### Ewallet ###
* Customers can be associated(pay) with `EWallet` accounts
* Each wallet must have ***customer's ID***, ***username***, ***(encoded) password***, and ***Current balance***
* *Security purpose* -> password **cannot be stored directly**. 
* The `HashCode()` method must be used to encode the plain text to integer value.
  * for example `"myP@ssW0rd".hashCode()` will get the value `-1840995161`

### CreditCard ###
* Credit card information includes ***card number*** and ***card type***

Type   | Card number (length , Start with) | Formatted Card number
-------|-----------------------------------|---
VISA   | 16 , 4 | #### #### #### ####
JCB    | 16 , 3528 to 3589 | #### #### #### ####
MASTERCARD| 16 , 51 or 52 | #### #### #### ####
AMERICANEXPRESS| 16 , 34 or 37 | ### ###### ######

### Payment ###
* Method `paid()` cannot be implemented yet and has to define as an *abstract method* 
* 3 Subclass named `PaymentCash`, `PaymentEWallet`, and `PaymentCreditCard` have to **extend** `Payment` and **implement** method `paid()`
* E-wallet and credit card payment require a customer to autorize the ***payment transaction***
* Both classes have to ***implement*** `Authorization` interface and implement abstract method named `authorize()`

## Note: Make sure that each payment class extend correct class & implement correct interface (can see the code in given `TestCaseTask1.java` 


