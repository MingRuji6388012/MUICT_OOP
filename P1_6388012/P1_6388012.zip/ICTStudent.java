//Name: Rujiphart Charatvaraphan
//ID: 6388012
//Section: 1
public class ICTStudent extends Student{
    public ICTStudent(CanteenICT _canteen){
        super(_canteen);
        this.customerType = CustomerType.ICTSTUDENT;
    }
}